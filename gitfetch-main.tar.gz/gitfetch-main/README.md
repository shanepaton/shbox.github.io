# gitfetch
A CLI for fetching Github and Gitlab profiles.
